<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
?>
<div class="main">

<div class="starttest">
	<p>Final Score: 

		<?php 
		if (isset($_SESSION['score'])) {
			echo $_SESSION['score'];
			unset($_SESSION['score']);
		}
		 ?>

	</p>

	<a href="viewans.php" style="background-color: lightblue;">View Ans</a>
	<a href="starttest.php" style="background-color: lightgreen;">Start Again</a>
</div>
	
  </div>
