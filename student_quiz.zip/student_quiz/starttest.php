<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
$question = $exm->getQuestion();
$total = $exm->getTotalRows();
?>
<div class="main">
<h1 style="background-color: lightblue;color:#fff;text-align: center;">Welcome to Quiz Test</h1>
	<div class="starttest">

		<ul>
			<li><strong>Number of Questions:</strong> <?php echo $total; ?></li>
		</ul>

		<a href="test.php?q=<?php echo $question['quesNo']; ?>" style="width:30%;text-align: center;background-color: lightgreen;color: #fff;">Start Test</a>

	</div>

  </div>
