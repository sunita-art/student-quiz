<?php include 'inc/header.php'; ?>
<?php
Session::checkSession();
?>
<div class="main">
<h1 style="background-color: lightblue;color:#fff;text-align: center;">Welcome to Quiz - Start Now</h1>
	
	<div class="segment">
	<h2>Quiz Test</h2>
	<ul>
		<li><a href="starttest.php" style="background-color: lightblue;color: #000;">Start Now...</a></li>
	</ul>
	</div>
	
  </div>
